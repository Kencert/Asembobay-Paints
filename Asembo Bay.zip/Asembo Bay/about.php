<!-- <?php include( 'couch/cms.php' ); ?>
<cms:template title='About Us' />
 -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Asembo Bay| About Us </title>
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<script type="text/javascript" src="java.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<header class = "main-header" style="margin-top: 0px; margin-left: 0px; z-index: 1; font-size: 14px; font-weight: bold;   ">
  
<img src="img/satlogo.png" style="float: left; margin-left: 10px; margin-top: 10px; width: 150px; height: 90px;" >
  
  <!-- Menu bar appearance and elements. -->

 <label for="show-menu" class="show-menu">&#9776;</label>
<input type="checkbox" id="show-menu" role="button" style="height:50px;  background-color:#f0f0ed; color: #001971; font-size: 14px; font-weight: bold; line-height: 10px;padding-right: 30px; padding-left: 30px; "  onMouseOver="this.style.backgroundColor='rgb(0, 25, 113)', this.style.color='white'"
   onMouseOut="this.style.backgroundColor='#f0f0ed',this.style.color='#001971'">
  <ul id="menu" style=" margin-top: 10px; background: #f0f0ed; text-transform: uppercase;  ">
    <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
        <li><a href="contact.php">Contact Us</a></li>
    <li>
      <div class="dropdown">
<button onclick="myFunction()" class="dropbtn"  style="height:50px;  background-color:#f0f0ed; color: #001971; font-size: 14px; font-weight: bold; line-height: 10px;padding-right: 30px; padding-left: 30px; "  onMouseOver="this.style.backgroundColor='rgb(0, 25, 113)', this.style.color='white'"
   onMouseOut="this.style.backgroundColor='#f0f0ed',this.style.color='#001971'">COMPANY ￬</button>
  <div id="myDropdown" class="dropdown-content" style="line-height: 10px;">
    <a href="about.php">About Us</a>
    <a href="what.php">What we Do</a>
    <a href="#about">Overview</a>
    <a href="#about">Career</a>
    <a href="#about">Download</a>
  </div>
</div>
      
            </li>
    
        
  </ul>

  </header>
	<div style="text-align:left; width: 100%; background-color: #f0f0ed; line-height: 1.5; color: black;"><p style="font-size: 22px; margin-left: 20px; margin-top: 105px;">
   <b> Home / About Us</p></b></div>
<div class="article" style="background-color:white; margin-top: 10px;">
	
</div>
<!-- <cms:editable name='main_content' type='richtext'>
 -->
<div style="background-color: #f0f0ed;" >

<p class="article">
Asembo Bay Enterprises & General Hardware., is a leading distributor of paints,PVC ceiling,Tiles within Kisumu and its environs.We are located,in Kisumu Kenya, we boasts of exponential growth over the years since establishment in 2014.Asembo bay paints and general hardware  has since grown to be recognized as a leading player in distribution of paints and other hardware materials in, Kisumu County,Migori County,Kisii county and neighbouring region alike. Main focus revolves around the supply of exterior and interior paints,automotive paints,road marking paints, tiles, PVC ceilings,glass mart,turpentine,standard thinner,white spirit,tile cutter,glass cutter,door hinges and other building equipments. 
</p>
<h5 id="mission">Mission</h5>
<p class="article">To be the distributor of choice for innovative and high quality Security Systems that complement and enhance the functionality of high-performance equipment in the industry.</p>
<h5 id="gallery">Vision</h5>
<p class="article">We aim to be the largest distributor of automatic intruder alarm equipment, CCTV cameras, batteries, telecommunication equipment and accessories in greater East African region.</p>

<h5 id="Values" >Our Core Values</h5> 
<p class="article">
Ethical - Apply ‘best practice’ to the benefit of both internal and external stakeholders.<br>
Discreet - Confidentiality is absolute in our dealings <br>
Flexible - We believe in providing a flexible approach to business, tailoring specific 	practice, solutions and services.<br>
Reliable – Building long lasting relationships</p>



</div>
<!-- </cms:editable> -->
<div class="footer"  style="bottom: 20px;  right: 0px;  width: 100%; font-size: 20px; background-color:#f0f0ed;  text-align: center; z-index: 4;  margin-top: 60px;  color: black;">
          © Copyright 2018. Asembo Bay Hardware. <br> All Rights Reserved.<br>
           </div>
 </body>
 
 </html>
